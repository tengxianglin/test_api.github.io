
var RTD_SEARCH_CONFIG = {"default_filter": "project:/", "filters": []};